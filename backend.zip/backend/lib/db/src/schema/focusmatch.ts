import { createInsertSchema } from "drizzle-zod";
import {
  boolean,
  index,
  integer,
  numeric,
  pgEnum,
  pgTable,
  text,
  timestamp,
  uniqueIndex,
  uuid,
} from "drizzle-orm/pg-core";
import { z } from "zod";

export const matchStatusEnum = pgEnum("match_status", [
  "queued",
  "active",
  "completed",
  "forfeited",
]);

export const usersTable = pgTable(
  "users",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    collegeEmailHash: text("college_email_hash").notNull(),
    isVerified: boolean("is_verified").notNull().default(false),
    createdAt: timestamp("created_at", { withTimezone: true })
      .notNull()
      .defaultNow(),
    currentStreak: integer("current_streak").notNull().default(0),
    totalMatches: integer("total_matches").notNull().default(0),
    totalWins: integer("total_wins").notNull().default(0),
    totalLosses: integer("total_losses").notNull().default(0),
    totalDraws: integer("total_draws").notNull().default(0),
  },
  (table) => [
    uniqueIndex("users_college_email_hash_unique").on(table.collegeEmailHash),
  ],
);

export const anonProfilesTable = pgTable(
  "anon_profiles",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    userId: uuid("user_id")
      .notNull()
      .references(() => usersTable.id, { onDelete: "cascade" }),
    anonUsername: text("anon_username").notNull(),
    avatarSeed: text("avatar_seed").notNull(),
    rotatesPerMatch: boolean("rotates_per_match").notNull().default(false),
  },
  (table) => [
    uniqueIndex("anon_profiles_user_unique").on(table.userId),
    uniqueIndex("anon_profiles_username_unique").on(table.anonUsername),
  ],
);

export const matchesTable = pgTable(
  "matches",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    user1Id: uuid("user1_id")
      .notNull()
      .references(() => usersTable.id, { onDelete: "cascade" }),
    user2Id: uuid("user2_id")
      .notNull()
      .references(() => usersTable.id, { onDelete: "cascade" }),
    status: matchStatusEnum("status").notNull().default("active"),
    startTime: timestamp("start_time", { withTimezone: true }).notNull(),
    endTime: timestamp("end_time", { withTimezone: true }).notNull(),
    winnerId: uuid("winner_id").references(() => usersTable.id, {
      onDelete: "set null",
    }),
    completedAt: timestamp("completed_at", { withTimezone: true }),
    createdAt: timestamp("created_at", { withTimezone: true })
      .notNull()
      .defaultNow(),
  },
  (table) => [
    index("matches_user1_idx").on(table.user1Id),
    index("matches_user2_idx").on(table.user2Id),
    index("matches_status_end_time_idx").on(table.status, table.endTime),
  ],
);

export const matchParticipantsTable = pgTable(
  "match_participants",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    matchId: uuid("match_id")
      .notNull()
      .references(() => matchesTable.id, { onDelete: "cascade" }),
    userId: uuid("user_id")
      .notNull()
      .references(() => usersTable.id, { onDelete: "cascade" }),
    anonUsername: text("anon_username").notNull(),
    avatarSeed: text("avatar_seed").notNull(),
  },
  (table) => [
    uniqueIndex("match_participants_match_user_unique").on(
      table.matchId,
      table.userId,
    ),
    index("match_participants_match_idx").on(table.matchId),
  ],
);

export const matchQueueTable = pgTable(
  "match_queue",
  {
    userId: uuid("user_id")
      .notNull()
      .primaryKey()
      .references(() => usersTable.id, { onDelete: "cascade" }),
    queuedAt: timestamp("queued_at", { withTimezone: true })
      .notNull()
      .defaultNow(),
  },
  (table) => [index("match_queue_queued_at_idx").on(table.queuedAt)],
);

export const matchTasksTable = pgTable(
  "match_tasks",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    matchId: uuid("match_id")
      .notNull()
      .references(() => matchesTable.id, { onDelete: "cascade" }),
    userId: uuid("user_id")
      .notNull()
      .references(() => usersTable.id, { onDelete: "cascade" }),
    description: text("description").notNull(),
    isCompleted: boolean("is_completed").notNull().default(false),
    createdAt: timestamp("created_at", { withTimezone: true })
      .notNull()
      .defaultNow(),
    completedAt: timestamp("completed_at", { withTimezone: true }),
  },
  (table) => [
    index("match_tasks_match_user_idx").on(table.matchId, table.userId),
  ],
);

export const focusSessionsTable = pgTable(
  "focus_sessions",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    matchId: uuid("match_id")
      .notNull()
      .references(() => matchesTable.id, { onDelete: "cascade" }),
    userId: uuid("user_id")
      .notNull()
      .references(() => usersTable.id, { onDelete: "cascade" }),
    clientSessionId: text("client_session_id").notNull(),
    startedAt: timestamp("started_at", { withTimezone: true }).notNull(),
    durationMinutes: integer("duration_minutes").notNull(),
    completed: boolean("completed").notNull().default(false),
    completedAt: timestamp("completed_at", { withTimezone: true }),
  },
  (table) => [
    uniqueIndex("focus_sessions_client_id_unique").on(
      table.userId,
      table.clientSessionId,
    ),
    index("focus_sessions_match_user_idx").on(table.matchId, table.userId),
  ],
);

export const matchResultsTable = pgTable(
  "match_results",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    matchId: uuid("match_id")
      .notNull()
      .references(() => matchesTable.id, { onDelete: "cascade" }),
    userId: uuid("user_id")
      .notNull()
      .references(() => usersTable.id, { onDelete: "cascade" }),
    totalFocusMinutes: integer("total_focus_minutes").notNull().default(0),
    tasksCompleted: integer("tasks_completed").notNull().default(0),
    sessionsCompleted: integer("sessions_completed").notNull().default(0),
    finalScore: numeric("final_score", {
      precision: 12,
      scale: 1,
      mode: "number",
    })
      .notNull()
      .default(0),
  },
  (table) => [
    uniqueIndex("match_results_match_user_unique").on(
      table.matchId,
      table.userId,
    ),
    index("match_results_match_idx").on(table.matchId),
  ],
);

export const otpCodesTable = pgTable(
  "otp_codes",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    emailHash: text("email_hash").notNull(),
    codeHash: text("code_hash").notNull(),
    expiresAt: timestamp("expires_at", { withTimezone: true }).notNull(),
    attempts: integer("attempts").notNull().default(0),
    consumedAt: timestamp("consumed_at", { withTimezone: true }),
    createdAt: timestamp("created_at", { withTimezone: true })
      .notNull()
      .defaultNow(),
  },
  (table) => [index("otp_codes_email_created_idx").on(table.emailHash, table.createdAt)],
);

export const insertUserSchema = createInsertSchema(usersTable);
export const insertAnonProfileSchema = createInsertSchema(anonProfilesTable);
export const insertMatchSchema = createInsertSchema(matchesTable);
export const insertMatchTaskSchema = createInsertSchema(matchTasksTable);
export const insertFocusSessionSchema = createInsertSchema(focusSessionsTable);
export const insertMatchResultSchema = createInsertSchema(matchResultsTable);

export type User = typeof usersTable.$inferSelect;
export type AnonProfile = typeof anonProfilesTable.$inferSelect;
export type Match = typeof matchesTable.$inferSelect;
export type MatchParticipant = typeof matchParticipantsTable.$inferSelect;
export type MatchQueueEntry = typeof matchQueueTable.$inferSelect;
export type MatchTask = typeof matchTasksTable.$inferSelect;
export type FocusSession = typeof focusSessionsTable.$inferSelect;
export type MatchResult = typeof matchResultsTable.$inferSelect;
export type OtpCode = typeof otpCodesTable.$inferSelect;

export const uuidSchema = z.string().uuid();