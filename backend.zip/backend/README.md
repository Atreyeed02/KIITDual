# KIITDual Backend

Backend API for KIITDual, an anonymous 1v1 study accountability platform for verified KIIT students.

## Run & Operate

- `pnpm --filter @workspace/api-server run dev` — run the API server (port 5000)
- `pnpm run typecheck` — full typecheck across all packages
- `pnpm run build` — typecheck + build all packages
- `pnpm --filter @workspace/api-spec run codegen` — regenerate API hooks and Zod schemas from the OpenAPI spec
- `pnpm --filter @workspace/db run push` — push DB schema changes (dev only)
- Required env: `DATABASE_URL` — Postgres connection string
- Required env: `PORT` — e.g. 5000
- Required env: `SESSION_SECRET` — signing secret for the httpOnly session cookie
- Optional env: `COLLEGE_EMAIL_DOMAINS` — comma-separated allowlist, defaults to `kiit.ac.in`
- Optional env: `DEV_OTP_CODE` — development-only OTP, defaults to `123456`

## Stack

- pnpm workspaces, Node.js 24, TypeScript 5.9
- API: Express 5
- DB: PostgreSQL + Drizzle ORM
- Validation: Zod (`zod/v4`), `drizzle-zod`
- API codegen: Orval (from OpenAPI spec)
- Build: esbuild (CJS bundle)

## Where things live

- `apps/api-server/src/routes/` — auth, users, matchmaking, and match workspace endpoints
- `apps/api-server/src/lib/match.ts` — queueing, score calculation, match completion, and privacy-safe response orientation
- `lib/db/src/schema/focusmatch.ts` — PostgreSQL source-of-truth schema
- `lib/api-spec/openapi.yaml` — source-of-truth REST contract
- `lib/api-client-react/src/generated/` and `lib/api-zod/src/generated/` — generated client and validation types

## Architecture decisions

- Authentication follows the frontend handoff: OTP request/verification creates an httpOnly signed session cookie; no email address is returned to clients.
- The pilot uses PostgreSQL for the matchmaking queue so the backend works with the supplied database without requiring Redis.
- Matches snapshot anonymous identities in `match_participants`, so regenerating an identity never rewrites old scorecards.
- The server is authoritative for match expiry and scoring; the frontend timer is display-only once API mode is connected.

## Product

- College-domain OTP sign-in with anonymous profile creation
- Matchmaking queue and active 24-hour 1v1 matches
- Private tasks, Pomodoro session logging, scorecards, history, and streak updates
- Account deletion and identity regeneration

## User preferences

_Populate as you build — explicit user instructions worth remembering across sessions._

## Gotchas

- Run `pnpm --filter @workspace/api-spec run codegen` after changing `lib/api-spec/openapi.yaml`.
- Run `pnpm --filter @workspace/db run push` after changing the Drizzle schema in development.
- Development OTP defaults to `123456`; production email delivery still needs a provider integration before publishing.

