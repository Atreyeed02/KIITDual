import { createHmac, createHash, randomInt, timingSafeEqual } from "node:crypto";
import type { NextFunction, Request, Response } from "express";
import { logger } from "./logger";

export const SESSION_COOKIE = "focusmatch_session";
const SESSION_TTL_SECONDS = 60 * 60 * 24 * 7;

const adjectives = [
  "Quiet",
  "Calm",
  "Swift",
  "Steady",
  "Clear",
  "Silent",
  "Focused",
  "Bright",
];
const animals = [
  "Falcon",
  "Wolf",
  "Bear",
  "Otter",
  "Fox",
  "Bison",
  "Moose",
  "Lynx",
];

export function normalizeEmail(email: string): string {
  return email.trim().toLowerCase();
}

export function hashEmail(email: string): string {
  return createHash("sha256").update(normalizeEmail(email)).digest("hex");
}

function secret(): string {
  const configured = process.env.SESSION_SECRET;
  if (configured) return configured;

  if (process.env.NODE_ENV === "production") {
    throw new Error("SESSION_SECRET is required in production.");
  }

  logger.warn("SESSION_SECRET is not configured; using a development-only secret");
  return "focusmatch-development-session-secret";
}

function hashWithSecret(value: string, purpose: string): string {
  return createHmac("sha256", secret()).update(`${purpose}:${value}`).digest("hex");
}

export function hashOtp(code: string): string {
  return hashWithSecret(code, "otp");
}

export function generateOtp(): string {
  return String(randomInt(0, 1_000_000)).padStart(6, "0");
}

export function generateAnonymousIdentity(): {
  anonUsername: string;
  avatarSeed: string;
} {
  const adjective = adjectives[randomInt(0, adjectives.length)] ?? "Quiet";
  const animal = animals[randomInt(0, animals.length)] ?? "Falcon";
  const number = randomInt(100, 1000);
  const anonUsername = `${adjective}${animal}${number}`;
  return { anonUsername, avatarSeed: `${anonUsername}-${randomInt(0, 1_000_000)}` };
}

type SessionPayload = {
  userId: string;
  expiresAt: number;
};

function encode(value: string): string {
  return Buffer.from(value, "utf8").toString("base64url");
}

function decode(value: string): string {
  return Buffer.from(value, "base64url").toString("utf8");
}

export function createSessionToken(userId: string): string {
  const payload: SessionPayload = {
    userId,
    expiresAt: Date.now() + SESSION_TTL_SECONDS * 1000,
  };
  const encodedPayload = encode(JSON.stringify(payload));
  const signature = hashWithSecret(encodedPayload, "session");
  return `${encodedPayload}.${signature}`;
}

export function verifySessionToken(token: string | undefined): string | null {
  if (!token) return null;
  const [encodedPayload, signature] = token.split(".");
  if (!encodedPayload || !signature) return null;

  const expected = hashWithSecret(encodedPayload, "session");
  const providedBuffer = Buffer.from(signature, "hex");
  const expectedBuffer = Buffer.from(expected, "hex");
  if (
    providedBuffer.length !== expectedBuffer.length ||
    !timingSafeEqual(providedBuffer, expectedBuffer)
  ) {
    return null;
  }

  try {
    const payload = JSON.parse(decode(encodedPayload)) as SessionPayload;
    if (
      typeof payload.userId !== "string" ||
      typeof payload.expiresAt !== "number" ||
      payload.expiresAt <= Date.now()
    ) {
      return null;
    }
    return payload.userId;
  } catch {
    return null;
  }
}

export function setSessionCookie(res: Response, userId: string): void {
  res.cookie(SESSION_COOKIE, createSessionToken(userId), {
    httpOnly: true,
    sameSite: "lax",
    secure: process.env.NODE_ENV === "production",
    maxAge: SESSION_TTL_SECONDS * 1000,
    path: "/",
  });
}

export function clearSessionCookie(res: Response): void {
  res.clearCookie(SESSION_COOKIE, { httpOnly: true, sameSite: "lax", path: "/" });
}

export function userIdFromRequest(req: Request): string | null {
  const cookieToken = req.cookies?.[SESSION_COOKIE] as string | undefined;
  const bearer = req.header("authorization");
  const bearerToken = bearer?.startsWith("Bearer ")
    ? bearer.slice("Bearer ".length)
    : undefined;
  return verifySessionToken(cookieToken ?? bearerToken);
}

export function requireAuth(
  req: Request,
  res: Response,
  next: NextFunction,
): void {
  const userId = userIdFromRequest(req);
  if (!userId) {
    res.status(401).json({
      error: {
        code: "UNAUTHENTICATED",
        message: "You must be signed in to do that.",
        details: {},
      },
    });
    return;
  }

  req.userId = userId;
  next();
}