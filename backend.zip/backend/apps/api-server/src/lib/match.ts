import {
  and,
  asc,
  desc,
  eq,
  inArray,
  isNull,
  lt,
  or,
  sql,
} from "drizzle-orm";
import {
  anonProfilesTable,
  db,
  focusSessionsTable,
  matchParticipantsTable,
  matchQueueTable,
  matchResultsTable,
  matchTasksTable,
  matchesTable,
  type AnonProfile,
  type FocusSession,
  type Match,
  type MatchResult,
  type MatchTask,
  type User,
  usersTable,
} from "@workspace/db";
import { generateAnonymousIdentity } from "./auth";
import { logger } from "./logger";

export type PublicUser = Omit<User, "collegeEmailHash">;
export type PublicProfile = {
  id: string;
  userId: string;
  anonUsername: string;
  avatarSeed: string;
  rotatesPerMatch: boolean;
};

export type PublicMatch = {
  id: string;
  user1Id: "me";
  user2Id: "opponent";
  user1Profile: PublicProfile;
  user2Profile: PublicProfile;
  status: Match["status"];
  startTime: string;
  endTime: string;
  winnerId: "me" | "opponent" | null;
};

export type PublicTask = {
  id: string;
  matchId: string;
  userId: "me";
  description: string;
  isCompleted: boolean;
  createdAt: string;
  completedAt?: string;
};

export type PublicSession = {
  id: string;
  matchId: string;
  userId: "me";
  startedAt: string;
  durationMinutes: number;
  completed: boolean;
};

export type PublicResult = {
  id: string;
  matchId: string;
  userId: "me" | "opponent";
  totalFocusMinutes: number;
  tasksCompleted: number;
  sessionsCompleted: number;
  finalScore: number;
};

export type PublicHistory = {
  match: PublicMatch;
  userResult: PublicResult;
  opponentResult: PublicResult;
  isWinner: boolean;
  isDraw: boolean;
  completedAt: string;
};

export function userToPublic(user: User): PublicUser {
  const { collegeEmailHash: _emailHash, ...publicUser } = user;
  return publicUser;
}

function iso(value: Date): string {
  return value.toISOString();
}

function profileToPublic(
  profile: AnonProfile | typeof matchParticipantsTable.$inferSelect,
  publicUserId: string,
  rotatesPerMatch = false,
): PublicProfile {
  return {
    id: profile.id,
    userId: publicUserId,
    anonUsername: profile.anonUsername,
    avatarSeed: profile.avatarSeed,
    rotatesPerMatch,
  };
}

export async function getOrCreateProfile(
  userId: string,
): Promise<AnonProfile> {
  const [existing] = await db
    .select()
    .from(anonProfilesTable)
    .where(eq(anonProfilesTable.userId, userId))
    .limit(1);
  if (existing) return existing;

  for (let attempt = 0; attempt < 5; attempt += 1) {
    const identity = generateAnonymousIdentity();
    try {
      const [created] = await db
        .insert(anonProfilesTable)
        .values({ userId, ...identity })
        .returning();
      if (created) return created;
    } catch {
      // A username collision is safe to retry.
    }
  }

  throw new Error("Unable to create an anonymous profile.");
}

async function snapshotsForMatch(matchId: string) {
  return db
    .select()
    .from(matchParticipantsTable)
    .where(eq(matchParticipantsTable.matchId, matchId));
}

export async function orientMatch(
  match: Match,
  requesterId: string,
): Promise<PublicMatch | null> {
  const snapshots = await snapshotsForMatch(match.id);
  const meIsUser1 = match.user1Id === requesterId;
  const meId = meIsUser1 ? match.user1Id : match.user2Id;
  const opponentId = meIsUser1 ? match.user2Id : match.user1Id;
  const mySnapshot = snapshots.find((item) => item.userId === meId);
  const opponentSnapshot = snapshots.find(
    (item) => item.userId === opponentId,
  );
  if (!mySnapshot || !opponentSnapshot) return null;

  const winnerId =
    match.winnerId === null
      ? null
      : match.winnerId === meId
        ? "me"
        : "opponent";

  return {
    id: match.id,
    user1Id: "me",
    user2Id: "opponent",
    user1Profile: profileToPublic(mySnapshot, "me"),
    user2Profile: profileToPublic(opponentSnapshot, "opponent"),
    status: match.status,
    startTime: iso(match.startTime),
    endTime: iso(match.endTime),
    winnerId,
  };
}

export async function findCurrentMatch(
  userId: string,
): Promise<Match | undefined> {
  const [match] = await db
    .select()
    .from(matchesTable)
    .where(
      and(
        or(eq(matchesTable.user1Id, userId), eq(matchesTable.user2Id, userId)),
        eq(matchesTable.status, "active"),
      ),
    )
    .orderBy(desc(matchesTable.startTime))
    .limit(1);
  return match;
}

export async function queueUser(userId: string): Promise<{
  queuedAt: Date;
  match: Match | null;
}> {
  return db.transaction(async (tx) => {
    const current = await tx
      .select()
      .from(matchesTable)
      .where(
        and(
          or(eq(matchesTable.user1Id, userId), eq(matchesTable.user2Id, userId)),
          eq(matchesTable.status, "active"),
        ),
      )
      .limit(1);
    if (current[0]) {
      return { queuedAt: new Date(), match: current[0] };
    }

    const [existingQueue] = await tx
      .select()
      .from(matchQueueTable)
      .where(eq(matchQueueTable.userId, userId))
      .limit(1);
    if (!existingQueue) {
      await tx.insert(matchQueueTable).values({ userId });
    }

    const waiting = await tx
      .select()
      .from(matchQueueTable)
      .orderBy(asc(matchQueueTable.queuedAt))
      .limit(2);
    const requesterEntry = waiting.find((entry) => entry.userId === userId);
    if (waiting.length < 2 || !requesterEntry) {
      return {
        queuedAt: requesterEntry?.queuedAt ?? new Date(),
        match: null,
      };
    }

    const opponentEntry =
      waiting[0]?.userId === userId ? waiting[1] : waiting[0];
    if (!opponentEntry) return { queuedAt: requesterEntry.queuedAt, match: null };

    const now = new Date();
    const endTime = new Date(now.getTime() + 24 * 60 * 60 * 1000);
    const [match] = await tx
      .insert(matchesTable)
      .values({
        user1Id: userId,
        user2Id: opponentEntry.userId,
        status: "active",
        startTime: now,
        endTime,
      })
      .returning();
    if (!match) throw new Error("Unable to create match.");

    const [myProfile, opponentProfile] = await Promise.all([
      tx
        .select()
        .from(anonProfilesTable)
        .where(eq(anonProfilesTable.userId, userId))
        .limit(1),
      tx
        .select()
        .from(anonProfilesTable)
        .where(eq(anonProfilesTable.userId, opponentEntry.userId))
        .limit(1),
    ]);
    if (!myProfile[0] || !opponentProfile[0]) {
      throw new Error("Both matched users must have anonymous profiles.");
    }

    await tx.insert(matchParticipantsTable).values([
      {
        matchId: match.id,
        userId,
        anonUsername: myProfile[0].anonUsername,
        avatarSeed: myProfile[0].avatarSeed,
      },
      {
        matchId: match.id,
        userId: opponentEntry.userId,
        anonUsername: opponentProfile[0].anonUsername,
        avatarSeed: opponentProfile[0].avatarSeed,
      },
    ]);
    await tx
      .delete(matchQueueTable)
      .where(inArray(matchQueueTable.userId, [userId, opponentEntry.userId]));

    return { queuedAt: requesterEntry.queuedAt, match };
  });
}

export async function removeUserFromQueue(userId: string): Promise<void> {
  await db
    .delete(matchQueueTable)
    .where(eq(matchQueueTable.userId, userId));
}

export async function getQueueEntry(userId: string) {
  const [entry] = await db
    .select()
    .from(matchQueueTable)
    .where(eq(matchQueueTable.userId, userId))
    .limit(1);
  return entry;
}

export async function getTasksForMatch(
  matchId: string,
  userId: string,
): Promise<PublicTask[]> {
  const tasks = await db
    .select()
    .from(matchTasksTable)
    .where(
      and(
        eq(matchTasksTable.matchId, matchId),
        eq(matchTasksTable.userId, userId),
      ),
    )
    .orderBy(asc(matchTasksTable.createdAt));
  return tasks.map((task) => ({
    id: task.id,
    matchId: task.matchId,
    userId: "me",
    description: task.description,
    isCompleted: task.isCompleted,
    createdAt: iso(task.createdAt),
    ...(task.completedAt ? { completedAt: iso(task.completedAt) } : {}),
  }));
}

export async function getSessionsForMatch(
  matchId: string,
  userId: string,
): Promise<PublicSession[]> {
  const sessions = await db
    .select()
    .from(focusSessionsTable)
    .where(
      and(
        eq(focusSessionsTable.matchId, matchId),
        eq(focusSessionsTable.userId, userId),
      ),
    )
    .orderBy(asc(focusSessionsTable.startedAt));
  return sessions.map((session) => ({
    id: session.id,
    matchId: session.matchId,
    userId: "me",
    startedAt: iso(session.startedAt),
    durationMinutes: session.durationMinutes,
    completed: session.completed,
  }));
}

function score(
  totalFocusMinutes: number,
  tasksCompleted: number,
  sessionsCompleted: number,
): number {
  return 0.5 * totalFocusMinutes + 30 * tasksCompleted + 10 * sessionsCompleted;
}

export async function finalizeMatch(matchId: string): Promise<Match | undefined> {
  return db.transaction(async (tx) => {
    const [match] = await tx
      .select()
      .from(matchesTable)
      .where(eq(matchesTable.id, matchId))
      .limit(1);
    if (!match) return undefined;
    if (match.status === "completed") return match;
    if (match.status !== "active") return match;
    if (match.endTime.getTime() > Date.now()) return match;

    const users = [match.user1Id, match.user2Id];
    const tasks = await tx
      .select()
      .from(matchTasksTable)
      .where(
        and(
          eq(matchTasksTable.matchId, match.id),
          inArray(matchTasksTable.userId, users),
          eq(matchTasksTable.isCompleted, true),
        ),
      );
    const sessions = await tx
      .select()
      .from(focusSessionsTable)
      .where(
        and(
          eq(focusSessionsTable.matchId, match.id),
          inArray(focusSessionsTable.userId, users),
          eq(focusSessionsTable.completed, true),
        ),
      );

    const computed = users.map((userId) => {
      const userTasks = tasks.filter((task) => task.userId === userId);
      const userSessions = sessions.filter(
        (session) => session.userId === userId,
      );
      const totalFocusMinutes = userSessions.reduce(
        (total, session) => total + session.durationMinutes,
        0,
      );
      const tasksCompleted = userTasks.length;
      const sessionsCompleted = userSessions.length;
      return {
        matchId: match.id,
        userId,
        totalFocusMinutes,
        tasksCompleted,
        sessionsCompleted,
        finalScore: score(totalFocusMinutes, tasksCompleted, sessionsCompleted),
      };
    });
    const first = computed[0]!;
    const second = computed[1]!;
    const winnerId =
      first.finalScore === second.finalScore
        ? null
        : first.finalScore > second.finalScore
          ? first.userId
          : second.userId;

    await tx
      .update(matchesTable)
      .set({ status: "completed", winnerId, completedAt: new Date() })
      .where(and(eq(matchesTable.id, match.id), eq(matchesTable.status, "active")));
    await tx
      .insert(matchResultsTable)
      .values(computed)
      .onConflictDoNothing({
        target: [matchResultsTable.matchId, matchResultsTable.userId],
      });

    for (const result of computed) {
      const isDraw = winnerId === null;
      const isWinner = winnerId === result.userId;
      await tx
        .update(usersTable)
        .set({
          totalMatches: sql`${usersTable.totalMatches} + 1`,
          totalWins: sql`${usersTable.totalWins} + ${isWinner ? 1 : 0}`,
          totalLosses: sql`${usersTable.totalLosses} + ${
            isDraw ? 0 : isWinner ? 0 : 1
          }`,
          totalDraws: sql`${usersTable.totalDraws} + ${isDraw ? 1 : 0}`,
          currentStreak: sql`${usersTable.currentStreak} + 1`,
        })
        .where(eq(usersTable.id, result.userId));
    }
    return {
      ...match,
      status: "completed" as const,
      winnerId,
      completedAt: new Date(),
    };
  });
}

export async function finalizeExpiredMatches(): Promise<number> {
  const expired = await db
    .select({ id: matchesTable.id })
    .from(matchesTable)
    .where(
      and(
        eq(matchesTable.status, "active"),
        lt(matchesTable.endTime, new Date()),
      ),
    )
    .limit(100);
  let finalized = 0;
  for (const match of expired) {
    const result = await finalizeMatch(match.id);
    if (result?.status === "completed") finalized += 1;
  }
  return finalized;
}

export async function findMatchParticipant(
  matchId: string,
  userId: string,
): Promise<Match | undefined> {
  const [match] = await db
    .select()
    .from(matchesTable)
    .where(
      and(
        eq(matchesTable.id, matchId),
        or(eq(matchesTable.user1Id, userId), eq(matchesTable.user2Id, userId)),
      ),
    )
    .limit(1);
  return match;
}

export async function getResultRows(matchId: string): Promise<MatchResult[]> {
  return db
    .select()
    .from(matchResultsTable)
    .where(eq(matchResultsTable.matchId, matchId));
}

export function resultToPublic(
  result: MatchResult,
  requesterId: string,
  match: Match,
): PublicResult {
  return {
    id: result.id,
    matchId: result.matchId,
    userId: result.userId === requesterId ? "me" : "opponent",
    totalFocusMinutes: result.totalFocusMinutes,
    tasksCompleted: result.tasksCompleted,
    sessionsCompleted: result.sessionsCompleted,
    finalScore: result.finalScore,
  };
}

export async function historyForUser(
  userId: string,
): Promise<PublicHistory[]> {
  const matches = await db
    .select()
    .from(matchesTable)
    .where(
      and(
        or(eq(matchesTable.user1Id, userId), eq(matchesTable.user2Id, userId)),
        eq(matchesTable.status, "completed"),
      ),
    )
    .orderBy(desc(matchesTable.completedAt));

  const history: PublicHistory[] = [];
  for (const match of matches) {
    const publicMatch = await orientMatch(match, userId);
    const results = await getResultRows(match.id);
    const userResult = results.find((result) => result.userId === userId);
    const opponentResult = results.find((result) => result.userId !== userId);
    if (!publicMatch || !userResult || !opponentResult) continue;
    history.push({
      match: publicMatch,
      userResult: resultToPublic(userResult, userId, match),
      opponentResult: resultToPublic(opponentResult, userId, match),
      isWinner: userResult.finalScore > opponentResult.finalScore,
      isDraw: userResult.finalScore === opponentResult.finalScore,
      completedAt: iso(match.completedAt ?? match.endTime),
    });
  }
  return history;
}

export async function forfeitMatch(
  matchId: string,
  userId: string,
): Promise<boolean> {
  const [match] = await db
    .select()
    .from(matchesTable)
    .where(
      and(
        eq(matchesTable.id, matchId),
        or(eq(matchesTable.user1Id, userId), eq(matchesTable.user2Id, userId)),
        eq(matchesTable.status, "active"),
      ),
    )
    .limit(1);
  if (!match) return false;

  await db.transaction(async (tx) => {
    await tx
      .update(matchesTable)
      .set({ status: "forfeited", completedAt: new Date() })
      .where(and(eq(matchesTable.id, matchId), eq(matchesTable.status, "active")));
    await tx
      .delete(matchQueueTable)
      .where(eq(matchQueueTable.userId, userId));
    await tx
      .update(usersTable)
      .set({ currentStreak: 0 })
      .where(eq(usersTable.id, userId));
  });
  return true;
}

export async function addStarterTasks(
  matchId: string,
  userId: string,
): Promise<void> {
  const [existing] = await db
    .select({ id: matchTasksTable.id })
    .from(matchTasksTable)
    .where(
      and(
        eq(matchTasksTable.matchId, matchId),
        eq(matchTasksTable.userId, userId),
      ),
    )
    .limit(1);
  if (existing) return;
  await db.insert(matchTasksTable).values([
    { matchId, userId, description: "Set your first study goal" },
    { matchId, userId, description: "Complete one focused session" },
  ]);
}

export function startExpiryWorker(): NodeJS.Timeout {
  const interval = setInterval(() => {
    void finalizeExpiredMatches().then((count) => {
      if (count > 0) logger.info({ count }, "Expired matches finalized");
    }).catch((error: unknown) => {
      logger.error({ err: error }, "Failed to finalize expired matches");
    });
  }, 30_000);
  interval.unref();
  return interval;
}