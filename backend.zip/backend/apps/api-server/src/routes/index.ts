import { Router, type IRouter } from "express";
import healthRouter from "./health";
import authRouter from "./auth";
import usersRouter from "./users";
import matchmakingRouter from "./matchmaking";
import matchesRouter from "./matches";

const router: IRouter = Router();

router.use(healthRouter);
router.use(authRouter);
router.use(usersRouter);
router.use(matchmakingRouter);
router.use(matchesRouter);

export default router;
