import { Router, type IRouter, type Response } from "express";
import { and, eq } from "drizzle-orm";
import {
  db,
  focusSessionsTable,
  matchTasksTable,
} from "@workspace/db";
import { requireAuth } from "../lib/auth";
import { apiError } from "../lib/http";
import {
  finalizeMatch,
  findCurrentMatch,
  findMatchParticipant,
  forfeitMatch,
  getResultRows,
  getSessionsForMatch,
  getTasksForMatch,
  historyForUser,
  orientMatch,
  resultToPublic,
} from "../lib/match";
import { z } from "zod";

const router: IRouter = Router();
const taskBody = z.object({
  description: z.string().trim().min(1).max(200),
});
const taskUpdateBody = z.object({ isCompleted: z.boolean() });
const sessionStartBody = z.object({
  mode: z.enum(["standard", "deep"]).default("standard"),
  clientSessionId: z.string().min(1).max(160),
});
const sessionUpdateBody = z.object({ completed: z.boolean() });

function param(value: string | string[] | undefined): string | null {
  return Array.isArray(value) ? value[0] ?? null : value ?? null;
}

async function activeParticipant(
  matchId: string,
  userId: string,
  res: Response,
) {
  const match = await findMatchParticipant(matchId, userId);
  if (!match) {
    apiError(res, 403, "NOT_A_PARTICIPANT", "You are not part of this match.");
    return null;
  }
  if (match.status !== "active") {
    apiError(res, 409, "MATCH_NOT_ACTIVE", "This match is no longer active.");
    return null;
  }
  return match;
}

router.get("/matches/current", requireAuth, async (req, res): Promise<void> => {
  let match = await findCurrentMatch(req.userId!);
  if (match && match.endTime.getTime() <= Date.now()) {
    match = (await finalizeMatch(match.id)) ?? match;
  }
  if (!match || match.status !== "active") {
    res.json({ match: null, tasks: [], sessions: [], serverTime: new Date().toISOString() });
    return;
  }
  const publicMatch = await orientMatch(match, req.userId!);
  if (!publicMatch) {
    apiError(res, 500, "INTERNAL", "Unable to load the current match.");
    return;
  }
  const [tasks, sessions] = await Promise.all([
    getTasksForMatch(match.id, req.userId!),
    getSessionsForMatch(match.id, req.userId!),
  ]);
  res.json({
    match: publicMatch,
    tasks,
    sessions,
    serverTime: new Date().toISOString(),
  });
});

router.get("/matches/history", requireAuth, async (req, res): Promise<void> => {
  res.json(await historyForUser(req.userId!));
});

router.get("/matches/:id/result", requireAuth, async (req, res): Promise<void> => {
  const matchId = param(req.params.id);
  if (!matchId) {
    apiError(res, 400, "VALIDATION_ERROR", "A match id is required.");
    return;
  }
  const match = await findMatchParticipant(matchId, req.userId!);
  if (!match) {
    apiError(res, 403, "NOT_A_PARTICIPANT", "You are not part of this match.");
    return;
  }
  if (match.status === "active" && match.endTime.getTime() <= Date.now()) {
    await finalizeMatch(match.id);
  }
  const refreshed = await findMatchParticipant(matchId, req.userId!);
  if (!refreshed || refreshed.status !== "completed") {
    apiError(res, 409, "MATCH_NOT_COMPLETED", "This match has not ended yet.");
    return;
  }
  const publicMatch = await orientMatch(refreshed, req.userId!);
  const results = await getResultRows(matchId);
  const userResult = results.find((result) => result.userId === req.userId!);
  const opponentResult = results.find((result) => result.userId !== req.userId!);
  if (!publicMatch || !userResult || !opponentResult) {
    apiError(res, 500, "INTERNAL", "Unable to load the scorecard.");
    return;
  }
  res.json({
    match: publicMatch,
    userResult: resultToPublic(userResult, req.userId!, refreshed),
    opponentResult: resultToPublic(opponentResult, req.userId!, refreshed),
    isWinner: userResult.finalScore > opponentResult.finalScore,
    isDraw: userResult.finalScore === opponentResult.finalScore,
    completedAt: (refreshed.completedAt ?? refreshed.endTime).toISOString(),
  });
});

router.post("/matches/:id/tasks", requireAuth, async (req, res): Promise<void> => {
  const matchId = param(req.params.id);
  const parsed = taskBody.safeParse(req.body);
  if (!matchId || !parsed.success) {
    apiError(res, 400, "VALIDATION_ERROR", "Enter a study goal between 1 and 200 characters.");
    return;
  }
  const match = await activeParticipant(matchId, req.userId!, res);
  if (!match) return;
  const [task] = await db
    .insert(matchTasksTable)
    .values({ matchId, userId: req.userId!, description: parsed.data.description })
    .returning();
  if (!task) {
    apiError(res, 500, "INTERNAL", "Unable to add the study goal.");
    return;
  }
  res.status(201).json({
    id: task.id,
    matchId: task.matchId,
    userId: "me",
    description: task.description,
    isCompleted: task.isCompleted,
    createdAt: task.createdAt.toISOString(),
  });
});

router.patch(
  "/matches/:id/tasks/:taskId",
  requireAuth,
  async (req, res): Promise<void> => {
    const matchId = param(req.params.id);
    const taskId = param(req.params.taskId);
    const parsed = taskUpdateBody.safeParse(req.body);
    if (!matchId || !taskId || !parsed.success) {
      apiError(res, 400, "VALIDATION_ERROR", "A valid task update is required.");
      return;
    }
    const match = await activeParticipant(matchId, req.userId!, res);
    if (!match) return;
    const [task] = await db
      .update(matchTasksTable)
      .set({
        isCompleted: parsed.data.isCompleted,
        completedAt: parsed.data.isCompleted ? new Date() : null,
      })
      .where(
        and(
          eq(matchTasksTable.id, taskId),
          eq(matchTasksTable.matchId, matchId),
          eq(matchTasksTable.userId, req.userId!),
        ),
      )
      .returning();
    if (!task) {
      apiError(res, 404, "NOT_FOUND", "Study goal not found.");
      return;
    }
    res.json({
      id: task.id,
      matchId: task.matchId,
      userId: "me",
      description: task.description,
      isCompleted: task.isCompleted,
      createdAt: task.createdAt.toISOString(),
      ...(task.completedAt ? { completedAt: task.completedAt.toISOString() } : {}),
    });
  },
);

router.delete(
  "/matches/:id/tasks/:taskId",
  requireAuth,
  async (req, res): Promise<void> => {
    const matchId = param(req.params.id);
    const taskId = param(req.params.taskId);
    if (!matchId || !taskId) {
      apiError(res, 400, "VALIDATION_ERROR", "A match and task id are required.");
      return;
    }
    const match = await activeParticipant(matchId, req.userId!, res);
    if (!match) return;
    await db
      .delete(matchTasksTable)
      .where(
        and(
          eq(matchTasksTable.id, taskId),
          eq(matchTasksTable.matchId, matchId),
          eq(matchTasksTable.userId, req.userId!),
        ),
      );
    res.sendStatus(204);
  },
);

router.post(
  "/matches/:id/sessions",
  requireAuth,
  async (req, res): Promise<void> => {
    const matchId = param(req.params.id);
    const parsed = sessionStartBody.safeParse(req.body);
    if (!matchId || !parsed.success) {
      apiError(res, 400, "VALIDATION_ERROR", "A valid focus session is required.");
      return;
    }
    const match = await activeParticipant(matchId, req.userId!, res);
    if (!match) return;
    const [running] = await db
      .select({ id: focusSessionsTable.id })
      .from(focusSessionsTable)
      .where(
        and(
          eq(focusSessionsTable.matchId, matchId),
          eq(focusSessionsTable.userId, req.userId!),
          eq(focusSessionsTable.completed, false),
        ),
      )
      .limit(1);
    if (running) {
      apiError(res, 409, "SESSION_ALREADY_RUNNING", "A focus session is already running.");
      return;
    }

    const durationMinutes = parsed.data.mode === "deep" ? 50 : 25;
    const [session] = await db
      .insert(focusSessionsTable)
      .values({
        matchId,
        userId: req.userId!,
        clientSessionId: parsed.data.clientSessionId,
        startedAt: new Date(),
        durationMinutes,
      })
      .onConflictDoNothing({
        target: [focusSessionsTable.userId, focusSessionsTable.clientSessionId],
      })
      .returning();
    if (!session) {
      const [existing] = await db
        .select()
        .from(focusSessionsTable)
        .where(
          and(
            eq(focusSessionsTable.userId, req.userId!),
            eq(focusSessionsTable.clientSessionId, parsed.data.clientSessionId),
          ),
        )
        .limit(1);
      if (!existing) {
        apiError(res, 500, "INTERNAL", "Unable to start the focus session.");
        return;
      }
      res.status(201).json({
        id: existing.id,
        matchId: existing.matchId,
        userId: "me",
        startedAt: existing.startedAt.toISOString(),
        durationMinutes: existing.durationMinutes,
        completed: existing.completed,
      });
      return;
    }
    res.status(201).json({
      id: session.id,
      matchId: session.matchId,
      userId: "me",
      startedAt: session.startedAt.toISOString(),
      durationMinutes: session.durationMinutes,
      completed: session.completed,
    });
  },
);

router.patch(
  "/matches/:id/sessions/:sessionId",
  requireAuth,
  async (req, res): Promise<void> => {
    const matchId = param(req.params.id);
    const sessionId = param(req.params.sessionId);
    const parsed = sessionUpdateBody.safeParse(req.body);
    if (!matchId || !sessionId || !parsed.success) {
      apiError(res, 400, "VALIDATION_ERROR", "A valid focus session update is required.");
      return;
    }
    const match = await activeParticipant(matchId, req.userId!, res);
    if (!match) return;
    const [session] = await db
      .select()
      .from(focusSessionsTable)
      .where(
        and(
          eq(focusSessionsTable.id, sessionId),
          eq(focusSessionsTable.matchId, matchId),
          eq(focusSessionsTable.userId, req.userId!),
        ),
      )
      .limit(1);
    if (!session) {
      apiError(res, 404, "NOT_FOUND", "Focus session not found.");
      return;
    }
    if (
      parsed.data.completed &&
      Date.now() < session.startedAt.getTime() + session.durationMinutes * 60_000
    ) {
      apiError(res, 422, "SESSION_TOO_SHORT", "The focus session has not finished yet.");
      return;
    }
    const [updated] = await db
      .update(focusSessionsTable)
      .set({
        completed: parsed.data.completed,
        completedAt: parsed.data.completed ? new Date() : null,
      })
      .where(eq(focusSessionsTable.id, sessionId))
      .returning();
    res.json({
      id: updated!.id,
      matchId: updated!.matchId,
      userId: "me",
      startedAt: updated!.startedAt.toISOString(),
      durationMinutes: updated!.durationMinutes,
      completed: updated!.completed,
    });
  },
);

router.post(
  "/matches/:id/forfeit",
  requireAuth,
  async (req, res): Promise<void> => {
    const matchId = param(req.params.id);
    if (!matchId) {
      apiError(res, 400, "VALIDATION_ERROR", "A match id is required.");
      return;
    }
    const forfeited = await forfeitMatch(matchId, req.userId!);
    if (!forfeited) {
      apiError(res, 409, "MATCH_NOT_ACTIVE", "This match is no longer active.");
      return;
    }
    res.sendStatus(204);
  },
);

export default router;