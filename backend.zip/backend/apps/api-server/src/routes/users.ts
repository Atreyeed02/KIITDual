import { Router, type IRouter } from "express";
import { eq } from "drizzle-orm";
import { anonProfilesTable, db, usersTable } from "@workspace/db";
import { getOrCreateProfile } from "../lib/match";
import { generateAnonymousIdentity } from "../lib/auth";
import { requireAuth } from "../lib/auth";
import { apiError } from "../lib/http";
import { userToPublic } from "../lib/match";

const router: IRouter = Router();

router.get("/users/me", requireAuth, async (req, res): Promise<void> => {
  const [user] = await db
    .select()
    .from(usersTable)
    .where(eq(usersTable.id, req.userId!))
    .limit(1);
  if (!user) {
    apiError(res, 401, "UNAUTHENTICATED", "Your session is no longer valid.");
    return;
  }
  const profile = await getOrCreateProfile(user.id);
  res.json({ user: userToPublic(user), profile });
});

router.post(
  "/users/me/identity",
  requireAuth,
  async (req, res): Promise<void> => {
    const identity = generateAnonymousIdentity();
    const [profile] = await db
      .update(anonProfilesTable)
      .set(identity)
      .where(eq(anonProfilesTable.userId, req.userId!))
      .returning();
    if (!profile) {
      apiError(res, 404, "NOT_FOUND", "Anonymous profile not found.");
      return;
    }
    res.json(profile);
  },
);

router.delete("/users/me", requireAuth, async (req, res): Promise<void> => {
  await db.delete(usersTable).where(eq(usersTable.id, req.userId!));
  res.sendStatus(204);
});

export default router;