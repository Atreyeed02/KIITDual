import { Router, type IRouter } from "express";
import { requireAuth } from "../lib/auth";
import { apiError } from "../lib/http";
import {
  addStarterTasks,
  findCurrentMatch,
  getQueueEntry,
  orientMatch,
  queueUser,
  removeUserFromQueue,
} from "../lib/match";

const router: IRouter = Router();

router.get("/matchmaking/queue", requireAuth, async (req, res): Promise<void> => {
  const entry = await getQueueEntry(req.userId!);
  if (!entry) {
    res.status(204).send();
    return;
  }
  res.json({ status: "searching", queuedAt: entry.queuedAt.toISOString() });
});

router.post("/matchmaking/queue", requireAuth, async (req, res): Promise<void> => {
  const current = await findCurrentMatch(req.userId!);
  if (current) {
    const match = await orientMatch(current, req.userId!);
    res.status(409).json({
      error: {
        code: "ACTIVE_MATCH_EXISTS",
        message: "You already have an active match.",
        details: { match },
      },
    });
    return;
  }

  const result = await queueUser(req.userId!);
  if (!result.match) {
    res.status(202).json({
      status: "searching",
      queuedAt: result.queuedAt.toISOString(),
    });
    return;
  }

  await Promise.all([
    addStarterTasks(result.match.id, req.userId!),
    addStarterTasks(
      result.match.id,
      result.match.user1Id === req.userId!
        ? result.match.user2Id
        : result.match.user1Id,
    ),
  ]);
  const match = await orientMatch(result.match, req.userId!);
  res.status(202).json({
    status: "matched",
    queuedAt: result.queuedAt.toISOString(),
    match,
  });
});

router.delete("/matchmaking/queue", requireAuth, async (req, res): Promise<void> => {
  await removeUserFromQueue(req.userId!);
  res.sendStatus(204);
});

export default router;