import { Router, type IRouter } from "express";
import { and, desc, eq, gt, isNull, lt } from "drizzle-orm";
import { db, otpCodesTable, usersTable } from "@workspace/db";
import {
  clearSessionCookie,
  generateOtp,
  hashEmail,
  hashOtp,
  normalizeEmail,
  setSessionCookie,
} from "../lib/auth";
import { apiError } from "../lib/http";
import { userToPublic } from "../lib/match";
import { getOrCreateProfile } from "../lib/match";
import { z } from "zod";

const router: IRouter = Router();
const emailBody = z.object({ email: z.string().trim().toLowerCase().email() });
const loginBody = emailBody.extend({ otp: z.string().regex(/^\d{6}$/) });
const rateLimit = new Map<string, { count: number; resetAt: number }>();

function isRateLimited(key: string): boolean {
  const now = Date.now();
  const current = rateLimit.get(key);
  if (!current || current.resetAt <= now) {
    rateLimit.set(key, { count: 1, resetAt: now + 15 * 60_000 });
    return false;
  }
  current.count += 1;
  return current.count > 5;
}

function isAllowedCollegeEmail(email: string): boolean {
  const domains = (process.env.COLLEGE_EMAIL_DOMAINS ?? "kiit.ac.in")
    .split(",")
    .map((domain) => domain.trim().toLowerCase().replace(/^@/, ""))
    .filter(Boolean);
  return domains.some((domain) => email.endsWith(`@${domain}`));
}

router.post("/auth/register", async (req, res): Promise<void> => {
  const parsed = emailBody.safeParse(req.body);
  if (!parsed.success) {
    apiError(res, 400, "VALIDATION_ERROR", "Enter a valid college email address.");
    return;
  }
  const email = normalizeEmail(parsed.data.email);
  if (isRateLimited(`register:${req.ip}:${hashEmail(email)}`)) {
    apiError(res, 429, "RATE_LIMITED", "Too many attempts. Try again later.");
    return;
  }
  if (!isAllowedCollegeEmail(email)) {
    apiError(
      res,
      400,
      "INVALID_EMAIL_DOMAIN",
      "Use your verified college email address.",
    );
    return;
  }

  const emailHash = hashEmail(email);
  const code =
    process.env.NODE_ENV === "production"
      ? generateOtp()
      : process.env.DEV_OTP_CODE ?? "123456";

  await db
    .delete(otpCodesTable)
    .where(
      and(
        eq(otpCodesTable.emailHash, emailHash),
        lt(otpCodesTable.expiresAt, new Date()),
      ),
    );
  await db.insert(otpCodesTable).values({
    emailHash,
    codeHash: hashOtp(code),
    expiresAt: new Date(Date.now() + 10 * 60 * 1000),
  });

  req.log.info(
    { emailDomain: email.split("@")[1], deliveryMode: process.env.NODE_ENV === "production" ? "provider-pending" : "development" },
    "Verification code issued",
  );
  res.status(202).json({});
});

router.post("/auth/login", async (req, res): Promise<void> => {
  const parsed = loginBody.safeParse(req.body);
  if (!parsed.success) {
    apiError(res, 400, "VALIDATION_ERROR", "Enter your email and six-digit code.");
    return;
  }
  const email = normalizeEmail(parsed.data.email);
  if (isRateLimited(`login:${req.ip}:${hashEmail(email)}`)) {
    apiError(res, 429, "RATE_LIMITED", "Too many attempts. Try again later.");
    return;
  }
  if (!isAllowedCollegeEmail(email)) {
    apiError(res, 400, "INVALID_EMAIL_DOMAIN", "Use your verified college email address.");
    return;
  }

  const emailHash = hashEmail(email);
  const [otp] = await db
    .select()
    .from(otpCodesTable)
    .where(
      and(
        eq(otpCodesTable.emailHash, emailHash),
        isNull(otpCodesTable.consumedAt),
        gt(otpCodesTable.expiresAt, new Date()),
      ),
    )
    .orderBy(desc(otpCodesTable.createdAt))
    .limit(1);

  if (!otp || otp.attempts >= 5) {
    apiError(res, 400, "OTP_EXPIRED", "That code is invalid or has expired.");
    return;
  }

  if (hashOtp(parsed.data.otp) !== otp.codeHash) {
    await db
      .update(otpCodesTable)
      .set({ attempts: otp.attempts + 1 })
      .where(eq(otpCodesTable.id, otp.id));
    apiError(res, 400, "INVALID_OTP", "That code is invalid or has expired.");
    return;
  }

  await db
    .update(otpCodesTable)
    .set({ consumedAt: new Date() })
    .where(eq(otpCodesTable.id, otp.id));

  let [user] = await db
    .select()
    .from(usersTable)
    .where(eq(usersTable.collegeEmailHash, emailHash))
    .limit(1);
  if (!user) {
    [user] = await db
      .insert(usersTable)
      .values({ collegeEmailHash: emailHash, isVerified: true })
      .returning();
  } else if (!user.isVerified) {
    [user] = await db
      .update(usersTable)
      .set({ isVerified: true })
      .where(eq(usersTable.id, user.id))
      .returning();
  }
  if (!user) {
    apiError(res, 500, "INTERNAL", "Unable to create your account.");
    return;
  }

  const profile = await getOrCreateProfile(user.id);
  setSessionCookie(res, user.id);
  res.json({
    user: userToPublic(user),
    profile,
  });
});

router.post("/auth/logout", (_req, res): void => {
  clearSessionCookie(res);
  res.sendStatus(204);
});

export default router;